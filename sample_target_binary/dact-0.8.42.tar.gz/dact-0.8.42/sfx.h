#ifndef _DACT_SFX_H
#define _DACT_SFX_H

#include "dact.h"

ssize_t sfx_init_compress(int fd);
ssize_t sfx_init_decompress(int fd);

#endif
