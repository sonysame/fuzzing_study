#ifndef _LOCAL_GETPASS_H
#define _LOCAL_GETPASS_H

char *getpass(const char *prompt);

#endif
