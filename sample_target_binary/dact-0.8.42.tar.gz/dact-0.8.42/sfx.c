#include "dact.h"
#include "sfx.h"

ssize_t sfx_init_compress(int fd) {
	return(-1);
}

ssize_t sfx_init_decompress(int fd) {
	return(-1);
}
