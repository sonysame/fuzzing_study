#ifndef _LOCAL_MKSTEMP_H
#define _LOCAL_MKSTEMP_H

int mkstemp(char *template);

#endif
